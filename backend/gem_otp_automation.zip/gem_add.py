import re
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoAlertPresentException
from datetime import datetime, timedelta
import time
import platform

# OTP Handler for auto-fetching Gmail OTP
from otp_handler import handle_otp

print("⚡ Running GeM Automation Script...")

# ---------------- GOOGLE SHEET SETUP ----------------
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
client = gspread.authorize(creds)

sheet_url = input("👉 Enter Google Sheet URL or ID: ").strip()
match = re.search(r"/d/([a-zA-Z0-9-_]+)", sheet_url)
sheet_id = match.group(1) if match else sheet_url
print(f"✅ Using Sheet ID: {sheet_id}")

sheet = client.open_by_key(sheet_id).sheet1

# ---------------- READ DATA ----------------
rows = sheet.get_all_values()
products = []

for i, row in enumerate(rows[1:], start=2):  # skip header
    try:
        link = row[0].strip() if len(row) > 0 else ""   # A col = product link
        status = row[2].strip().upper() if len(row) > 2 else ""  # C col = status
        if link and status == "NEW":
            products.append((i, link, row))  # row bhi pass karenge
    except:
        continue

print(f"✅ Total NEW products to process: {len(products)}")
if not products:
    exit()

# ---------------- SELENIUM SETUP ----------------
options = Options()
options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
options.add_argument("--disable-popup-blocking")
prefs = {"profile.default_content_setting_values.popups": 0}
options.add_experimental_option("prefs", prefs)
driver = webdriver.Chrome(options=options)
wait = WebDriverWait(driver, 15)

# ---------------- HELPERS ----------------
IS_MAC = platform.system() == "Darwin"

def _dispatch_events(el):
    js = """
      const el = arguments[0];
      ['input','change','blur'].forEach(evt => el.dispatchEvent(new Event(evt, {bubbles:true})));
    """
    driver.execute_script(js, el)

def fill_field(el, value):
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", el)
    time.sleep(0.2)
    try:
        el.click()
    except:
        driver.execute_script("arguments[0].click();", el)
    time.sleep(0.15)

    if IS_MAC:
        el.send_keys(Keys.COMMAND, "a")
    else:
        el.send_keys(Keys.CONTROL, "a")
    time.sleep(0.05)
    el.send_keys(Keys.BACKSPACE)
    time.sleep(0.1)

    for ch in str(value):
        el.send_keys(ch)
        time.sleep(0.01)

    time.sleep(0.1)
    _dispatch_events(el)
    el.send_keys(Keys.TAB)
    time.sleep(0.2)

    try:
        current = el.get_attribute("value") or ""
        if str(current) != str(value):
            driver.execute_script("arguments[0].value = arguments[1];", el, str(value))
            _dispatch_events(el)
            el.send_keys(Keys.TAB)
            time.sleep(0.2)
    except:
        pass

def clean_number(s):
    return (s or "").replace(",", "").strip()

def two_dec(n):
    return f"{float(n):.2f}"

today = datetime.today().strftime("%Y-%m-%d")
two_years_later = (datetime.today() + timedelta(days=730)).strftime("%Y-%m-%d")

# ---------------- MAIN LOOP ----------------
for idx, (row_index, link, row) in enumerate(products, start=1):
    input(f"\n⏳ Form kholo manually (link open + Sell this item), phir ENTER dabao {idx}/{len(products)}...")

    try:
        # Always switch to the latest opened tab
        driver.switch_to.window(driver.window_handles[-1])
        print("✅ Switched to active tab")

        print("⏳ Waiting 2 seconds before filling...")
        time.sleep(2)

        try:
            fill_field(driver.find_element(By.NAME, "authorization_no"), "NA")
            fill_field(driver.find_element(By.NAME, "authorization_agency"), "NA")

            auth_date_elem = driver.find_element(By.XPATH, "//input[contains(@ng-model, 'authorization_date')]")
            fill_field(auth_date_elem, today)

            valid_from_elem = driver.find_element(By.XPATH, "//input[contains(@ng-model, 'authorization_valid_from')]")
            fill_field(valid_from_elem, today)

            valid_to_elem = driver.find_element(By.XPATH, "//input[contains(@ng-model, 'authorization_valid_to')]")
            fill_field(valid_to_elem, two_years_later)
            print("✅ Authorization details filled")

            state_checkboxes = driver.find_elements(By.XPATH, "//input[@type='checkbox']")
            for checkbox in state_checkboxes:
                if not checkbox.is_selected():
                    driver.execute_script("arguments[0].click();", checkbox)
                    time.sleep(0.2)
                    try:
                        alert = driver.switch_to.alert
                        alert.accept()
                    except NoAlertPresentException:
                        pass
            print("✅ All states selected")

            qty_elem = driver.find_element(By.NAME, "quantity")
            fill_field(qty_elem, "100000")

            # ---------------- Minimum Quantity Per Consignee ----------------
            try:
                moq_raw = row[9].strip() if len(row) > 9 else ""  # Column J
                if moq_raw:
                    moq_value = str(int(float(clean_number(moq_raw))))
                    moq_elem = driver.find_element(By.NAME, "moq")
                    fill_field(moq_elem, moq_value)
                    print(f"✅ Minimum Quantity Per Consignee filled: {moq_value}")
            except Exception as e:
                print(f"⚠ Error filling MOQ: {e}")

            try:
                lead_elem = driver.find_element(By.NAME, "lead_time")
                placeholder = lead_elem.get_attribute("placeholder") or ""
                highest_val = placeholder.split("-")[-1].replace("]", "").strip()
                highest_val = str(int(float(clean_number(highest_val))))
                fill_field(lead_elem, highest_val)
            except:
                pass

            try:
                offer_price_raw = row[10].strip() if len(row) > 10 else ""
                if offer_price_raw:
                    base = float(clean_number(offer_price_raw))
                    offer_price = two_dec(base - 0.01)
                    wsp_elem = driver.find_element(By.NAME, "wsp")
                    fill_field(wsp_elem, offer_price)
                    sheet.update_acell(f"E{row_index}", offer_price)
            except:
                pass

            undertaking_elem = driver.find_element(
                By.XPATH, "//input[@type='checkbox' and contains(@ng-model,'chain_document_declaration')]"
            )
            if not undertaking_elem.is_selected():
                driver.execute_script("arguments[0].click();", undertaking_elem)

            print("🎉 Form filled successfully!")
            
            # ---------------- SUBMIT FORM & HANDLE OTP ----------------
            try:
                # Find and click submit button
                submit_btn = driver.find_element(
                    By.XPATH, "//button[contains(@ng-click, 'submit') or contains(@ng-click, 'save') or contains(text(), 'Submit') or contains(text(), 'Save')]"
                )
                driver.execute_script("arguments[0].click();", submit_btn)
                print("📤 Form submitted, waiting for OTP...")
                time.sleep(2)
                
                # Auto-handle OTP
                if handle_otp(driver, max_retries=3, otp_timeout=120):
                    print("✅ OTP verified successfully!")
                    sheet.update_acell(f"C{row_index}", "ADDED")
                else:
                    print("❌ OTP verification failed")
                    sheet.update_acell(f"C{row_index}", "OTP_FAILED")
            except Exception as otp_error:
                print(f"⚠ Submit/OTP error: {otp_error}")
                # Fallback to manual
                input("👉 Please complete OTP manually, then press ENTER...")
                sheet.update_acell(f"C{row_index}", "ADDED")

        except Exception as e:
            print("⚠ Error while filling form:", e)

    except Exception as e:
        print(f"⚠️ Error in tab handling → {str(e)}")
        continue

print("\n🎉 Process finished! All NEW products handled.")
