# GEM Scraper module
